import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef } from "react";
import { Car, Flame, Leaf, Sparkles, Trees, Trophy } from "lucide-react";
import { toast } from "sonner";
import { ChallengeCard } from "@/components/quest/ChallengeCard";
import { Forest } from "@/components/quest/Forest";
import { Leaderboard } from "@/components/quest/Leaderboard";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAnimatedNumber } from "@/hooks/use-animated-number";
import { useQuest } from "@/hooks/use-quest";
import {
  CHALLENGES,
  CLASSES,
  POINTS_PER_TREE,
  currentStreak,
  forestLevel,
  leaderboard,
  pointsToNextTree,
  totalKgSaved,
  totalPoints,
  treeCount,
} from "@/lib/quest";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Carbon Footprint Quest — Daily green challenges" },
      {
        name: "description",
        content:
          "Bike, eat plant-based and skip plastic. Track kg of CO₂ saved, grow a virtual forest and climb the class leaderboard.",
      },
      { property: "og:title", content: "Carbon Footprint Quest" },
      {
        property: "og:description",
        content: "Daily green challenges, a growing forest and a class leaderboard for high schoolers.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

/** Rough average for a petrol car, used only for the fun comparison. */
const KG_PER_CAR_KM = 0.17;

function Index() {
  const quest = useQuest();
  const kg = totalKgSaved(quest.log);
  const points = totalPoints(quest.log);
  const trees = treeCount(points);
  const { level, current, next } = forestLevel(trees);
  const streak = quest.today ? currentStreak(quest.log, new Date()) : 0;
  const rows = useMemo(() => leaderboard(quest.classId, kg), [quest.classId, kg]);
  const myClass = CLASSES.find((c) => c.id === quest.classId)!;
  const myRank = rows.find((r) => r.isMine)?.rank ?? 0;
  const doneCount = quest.doneToday.size;

  const animatedKg = useAnimatedNumber(kg);
  const toNext = pointsToNextTree(points);
  const treeProgress = ((POINTS_PER_TREE - toNext) / POINTS_PER_TREE) * 100;

  // Celebrate new trees and level-ups (but not on first load).
  const prevTrees = useRef<number | null>(null);
  useEffect(() => {
    if (!quest.hydrated) return;
    if (prevTrees.current !== null && trees > prevTrees.current) {
      const leveledUp = forestLevel(prevTrees.current).level < level;
      toast.success(leveledUp ? `Level up: ${current.name}!` : "A new tree sprouted!", {
        description: leveledUp
          ? `Your forest reached level ${level}. Keep it growing.`
          : `${trees} tree${trees === 1 ? "" : "s"} in your forest.`,
      });
    }
    prevTrees.current = trees;
  }, [trees, level, current.name, quest.hydrated]);

  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-4 pt-6 sm:px-6">
        <div className="flex items-center gap-3">
          <span className="grid size-11 place-items-center rounded-2xl border-2 border-border bg-primary text-primary-foreground shadow-chunky-sm">
            <Leaf className="size-6" strokeWidth={2.5} />
          </span>
          <div>
            <h1 className="text-2xl leading-none font-extrabold tracking-tight sm:text-3xl">
              Carbon Footprint Quest
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">Small swaps. Real CO₂. Big forest.</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 rounded-full border-2 border-border bg-card px-3 py-1.5 text-sm font-bold">
            <Flame className="size-4 text-coral" strokeWidth={2.5} />
            {streak} day streak
          </span>
          <Select value={quest.classId} onValueChange={quest.setClassId}>
            <SelectTrigger
              aria-label="Your class"
              className="h-9 w-auto gap-2 rounded-full border-2 border-border bg-card font-bold"
            >
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {CLASSES.map((c) => (
                <SelectItem key={c.id} value={c.id}>
                  Class {c.name} · {c.teacher}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </header>

      <main className="mx-auto grid max-w-6xl gap-6 px-4 py-8 sm:px-6 lg:grid-cols-3">
        {/* CO2 counter */}
        <section className="panel flex flex-col justify-between gap-6 bg-primary p-6 text-primary-foreground">
          <div>
            <p className="text-sm font-bold tracking-widest uppercase opacity-80">Total CO₂ saved</p>
            <p className="mt-2 flex items-baseline gap-2">
              <span className="font-display text-6xl font-extrabold tracking-tight tabular-nums sm:text-7xl">
                {animatedKg.toFixed(1)}
              </span>
              <span className="font-display text-2xl font-bold">kg</span>
            </p>
            <p className="mt-3 flex items-center gap-2 text-sm opacity-90">
              <Car className="size-4" />≈ {Math.round(kg / KG_PER_CAR_KM)} km of car driving avoided
            </p>
          </div>
          <dl className="grid grid-cols-3 gap-2 text-primary-foreground">
            {[
              { label: "Points", value: points, icon: Sparkles },
              { label: "Trees", value: trees, icon: Trees },
              { label: "Class rank", value: `#${myRank}`, icon: Trophy },
            ].map(({ label, value, icon: Icon }) => (
              <div key={label} className="rounded-xl border-2 border-primary-foreground/30 p-3">
                <Icon className="size-4 opacity-80" />
                <dd className="mt-1 font-mono text-xl font-bold tabular-nums">{value}</dd>
                <dt className="text-xs opacity-80">{label}</dt>
              </div>
            ))}
          </dl>
        </section>

        {/* Forest */}
        <section className="panel overflow-hidden lg:col-span-2">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b-2 border-border px-5 py-3">
            <div>
              <p className="text-xs font-bold tracking-widest text-muted-foreground uppercase">
                Level {level}
              </p>
              <h2 className="text-xl font-extrabold">{current.name}</h2>
            </div>
            <div className="min-w-48 flex-1 sm:max-w-64">
              <div className="flex justify-between text-xs font-bold">
                <span>Next tree</span>
                <span className="font-mono">{toNext} pts to go</span>
              </div>
              <div className="mt-1 h-3 overflow-hidden rounded-full border-2 border-border bg-muted">
                <div
                  className="h-full bg-accent transition-[width] duration-700"
                  style={{ width: `${treeProgress}%` }}
                />
              </div>
              {next && (
                <p className="mt-1 text-xs text-muted-foreground">
                  {next.minTrees - trees} more tree{next.minTrees - trees === 1 ? "" : "s"} to reach{" "}
                  {next.name}
                </p>
              )}
            </div>
          </div>
          <Forest trees={trees} level={level} />
          {trees === 0 && (
            <p className="border-t-2 border-border bg-secondary px-5 py-2.5 text-center font-display font-bold">
              Complete challenges to plant your first tree 🌱
            </p>
          )}
        </section>

        {/* Daily challenges */}
        <section className="lg:col-span-2">
          <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
            <div>
              <p className="text-xs font-bold tracking-widest text-muted-foreground uppercase">
                Today's quests
              </p>
              <h2 className="text-2xl font-extrabold">Daily green challenges</h2>
            </div>
            <p className="rounded-full border-2 border-border bg-card px-3 py-1 font-mono text-sm font-bold">
              {doneCount}/{CHALLENGES.length} done
            </p>
          </div>
          <div className="grid gap-5 sm:grid-cols-3">
            {CHALLENGES.map((c) => (
              <ChallengeCard
                key={c.id}
                challenge={c}
                done={quest.doneToday.has(c.id)}
                onToggle={() => quest.toggle(c.id)}
              />
            ))}
          </div>
          {doneCount === CHALLENGES.length && (
            <p className="panel mt-5 flex items-center gap-2 bg-accent px-5 py-3 font-display font-bold animate-pop">
              <Sparkles className="size-5" /> Perfect day! Come back tomorrow for new quests.
            </p>
          )}
        </section>

        {/* Leaderboard */}
        <section className="panel p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <p className="text-xs font-bold tracking-widest text-muted-foreground uppercase">
                Leaderboard
              </p>
              <h2 className="text-2xl font-extrabold">Class battle</h2>
            </div>
            <Trophy className="size-7 text-primary" strokeWidth={2.25} />
          </div>
          <Leaderboard rows={rows} />
          <p className="mt-4 text-xs text-muted-foreground">
            Your savings count toward Class {myClass.name}.
          </p>
        </section>
      </main>

      <footer className="mx-auto max-w-6xl px-4 pb-10 text-xs text-muted-foreground sm:px-6">
        CO₂ figures are rough estimates to show the impact of everyday choices.
      </footer>
    </div>
  );
}
